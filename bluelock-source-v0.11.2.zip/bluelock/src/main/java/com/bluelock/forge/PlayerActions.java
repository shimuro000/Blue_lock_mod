package com.bluelock.forge;

import com.bluelock.common.action.DirectShot;
import com.bluelock.common.action.FootModel;
import com.bluelock.common.anim.AnimLogic;
import com.bluelock.common.action.KickModel;
import com.bluelock.common.action.PassAssist;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** What happens on the server when a player presses a football key (pass, shot, slide tackle, dribble skills). */
public final class PlayerActions {
    private static final String[] SKILL_FOR_ACTION = new String[ActionIds.COUNT];
    private static final int SLIDE_COST = 15;
    private static final int SLIDE_COOLDOWN = 50;

    static {
        SKILL_FOR_ACTION[ActionIds.FEINT] = "feint";
        SKILL_FOR_ACTION[ActionIds.BURST] = "burst_dribble";
        SKILL_FOR_ACTION[ActionIds.CHAIN] = "chain_dribble";
        SKILL_FOR_ACTION[ActionIds.SPRINT] = "sprint_burst";
        SKILL_FOR_ACTION[ActionIds.SHOULDER] = "shoulder_charge";
    }

    private PlayerActions() {
    }

    public static void handle(ServerPlayer player, int action) {
        switch (action) {
            case ActionIds.PASS -> pass(player);
            case ActionIds.SHOT -> shot(player);
            case ActionIds.SLIDE -> slide(player);
            case ActionIds.FEINT, ActionIds.BURST, ActionIds.CHAIN, ActionIds.SPRINT, ActionIds.SHOULDER -> skill(player, action);
            case ActionIds.VISION -> vision(player);
            case ActionIds.DEFENSE -> defense(player);
            case ActionIds.FOCUS -> focus(player);
            default -> { }
        }
    }

    // ---------- state checks used by other classes ----------

    static boolean isImmune(LivingEntity entity, long now) {
        if (entity instanceof ServerPlayer player) {
            PlayerState state = PlayerStates.peek(player.getUUID());
            return state != null && now < state.immuneUntil;
        }
        return false;
    }

    static boolean hasNoLoss(LivingEntity entity, long now) {
        if (entity instanceof ServerPlayer player) {
            PlayerState state = PlayerStates.peek(player.getUUID());
            return state != null && now < state.noLossUntil;
        }
        return false;
    }

    // ---------- kicks ----------

    /** The ball this player carries, or a loose ball right at their feet. */
    private static BallEntity ballFor(ServerPlayer player) {
        List<BallEntity> balls = player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(3.0));
        BallEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (BallEntity ball : balls) {
            if (ball.carrier() == player) {
                return ball;
            }
            double d = ball.distanceTo(player);
            if (ball.carrier() == null && d < 2.6 && d < bestDist) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    public static void pass(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        StatBlock stats = ActorStats.of(server, player);
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        boolean through = player.isShiftKeyDown() && hasSkill(player, "through_pass")
                && spendSkill(player, state, ActionIds.PASS, "through_pass", now);
        Vec3 look = player.getLookAngle();
        List<LivingEntity> mates = MatchManager.teammatesOf(player);
        List<double[]> positions = new ArrayList<>();
        for (LivingEntity mate : mates) {
            positions.add(new double[] {mate.getX(), mate.getZ()});
        }
        int target = PassAssist.pick(player.getX(), player.getZ(), look.x, look.z, positions, through ? 40.0 : 28.0, 3.0, 45.0);
        double dx = look.x;
        double dz = look.z;
        double distance = 0;
        if (target >= 0) {
            LivingEntity mate = mates.get(target);
            double lead = through ? 14 : 6;   // a through pass goes into the space ahead of the runner
            double leadX = mate.getX() + (mate.getX() - mate.xo) * lead;
            double leadZ = mate.getZ() + (mate.getZ() - mate.zo) * lead;
            dx = leadX - ball.getX();
            dz = leadZ - ball.getZ();
            distance = Math.sqrt(dx * dx + dz * dz);
        }
        boolean focused = now < state.focusUntil;
        FootModel.Factors foot = footFactors(server, player, dx, dz);
        Velocity v = KickModel.pass(dx, dz, distance, stats.permanent(Stat.PASSING),
                foot.spread() * (focused ? 0.6 : 1.0) * (through ? 0.8 : 1.0), foot.power() * (through ? 1.1 : 1.0),
                ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, false);
        AnimationBridge.playOnPlayer(player, through ? "through_pass" : "kick_pass");
        Rewards.give(server, player.getUUID(), through ? Progression.XpAction.SKILL_USED : Progression.XpAction.PASS);
    }

    /**
     * The shot key. With the ball at your feet it is a normal shot. If the ball is loose within 2 blocks (rolling or
     * flying after a pass) it is a direct shot: Direct, Precision or Awakening depending on the skills you own and
     * your Awakening Potential and Ego. Finishing, Pressure Finisher and Composure Focus improve any shot.
     */
    public static void shot(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        StatBlock stats = ActorStats.of(server, player);
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        Set<String> owned = ProfileSavedData.get(server).load(player.getUUID()).map(PlayerProfile::unlockedSkills).orElse(Set.of());
        boolean pressured = nearestOpponentDistance(player) < DirectShot.PRESSURE_DISTANCE;
        boolean finishing = owned.contains("finishing");
        boolean pressureSkill = owned.contains("pressure_finisher");
        boolean focused = now < state.focusUntil;

        DirectShot.Tier tier = DirectShot.Tier.NONE;
        DirectShot.Tuning tuning;
        if (ball.carrier() == null) {
            tier = DirectShot.bestTier(owned, stats.permanent(Stat.AWAKENING_POTENTIAL), stats.permanent(Stat.EGO_AFFINITY));
            if (tier != DirectShot.Tier.NONE && !spendDirectShot(player, state, tier, now)) {
                tier = DirectShot.Tier.NONE;   // too tired or on cooldown: an ordinary loose-ball shot
            }
            tuning = DirectShot.tuning(tier, pressured, finishing, pressureSkill, focused);
        } else {
            tuning = DirectShot.normalShot(pressured, finishing, pressureSkill, focused);
        }

        Vec3 look = player.getLookAngle();
        double[] dir = {look.x, look.y, look.z};
        Vec3 goal = MatchManager.attackTarget(player);
        if (goal != null && tuning.aimBlend() > 0) {
            double[] toGoal = {goal.x - ball.getX(), goal.y - ball.getY(), goal.z - ball.getZ()};
            dir = KickModel.aimToward(dir, toGoal, tier == DirectShot.Tier.NONE ? 18.0 : 28.0, tuning.aimBlend());
        }
        FootModel.Factors foot = footFactors(server, player, dir[0], dir[2]);
        Velocity v = KickModel.shot(dir[0], Math.max(dir[1], 0.0), dir[2],
                stats.permanent(Stat.SHOOTING), stats.permanent(Stat.FINISHING), stats.permanent(Stat.SHOT_POWER),
                1.0, 0.12, foot.spread() * tuning.spreadMul(), foot.power() * tuning.powerMul(),
                ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, true);
        AnimationBridge.playOnPlayer(player, switch (tier) {
            case AWAKENING -> "awakening_shot";
            case DIRECT, PRECISION -> "volley";
            default -> "kick_shot";
        });
        Rewards.give(server, player.getUUID(), tier == DirectShot.Tier.NONE ? Progression.XpAction.SHOT : Progression.XpAction.SKILL_USED);
    }

    private static boolean spendDirectShot(ServerPlayer player, PlayerState state, DirectShot.Tier tier, long now) {
        String skillId = switch (tier) {
            case AWAKENING -> "awakening_direct_shot";
            case PRECISION -> "precision_direct_shot";
            default -> "direct_shot";
        };
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(skillId);
        if (def.isEmpty() || now < state.readyAt[ActionIds.SHOT]) {
            return false;
        }
        int extra = DirectShot.tuning(tier, false, false, false, false).extraStamina();
        if (!state.stamina.spend(def.get().staminaCost() + extra)) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return false;
        }
        state.startCooldown(ActionIds.SHOT, now, def.get().cooldownTicks());
        return true;
    }

    /** Accuracy and power from the player's dominant foot: kicks across the body use the weak foot. */
    private static FootModel.Factors footFactors(MinecraftServer server, ServerPlayer player, double dx, double dz) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player.getUUID());
        if (profile.isEmpty()) {
            return new FootModel.Factors(1.0, 1.0);
        }
        Vec3 h = heading(player);
        return FootModel.kick(profile.get().foot(), FootModel.sideOf(h.x, h.z, dx, dz));
    }

    // ---------- helpers for skills ----------

    /** Does this player or bot own the skill? */
    static boolean hasSkill(LivingEntity entity, String skillId) {
        if (entity instanceof ServerPlayer player) {
            return ProfileSavedData.get(player.getServer()).load(player.getUUID()).map(p -> p.isUnlocked(skillId)).orElse(false);
        }
        return entity instanceof BotEntity bot && bot.hasSkill(skillId);
    }

    /** Extra Anticipation for a tackler who is shadow-marking the carrier. */
    static int markBonus(LivingEntity tackler, LivingEntity carrier, long now) {
        if (tackler instanceof ServerPlayer player) {
            PlayerState state = PlayerStates.peek(player.getUUID());
            if (state != null && now < state.markUntil && state.markedId == carrier.getId()) {
                return 20;
            }
        }
        return 0;
    }

    static boolean isIntercepting(Player player, long now) {
        PlayerState state = PlayerStates.peek(player.getUUID());
        return state != null && now < state.interceptUntil;
    }

    static double nearestOpponentDistance(ServerPlayer player) {
        double best = Double.MAX_VALUE;
        List<LivingEntity> foes = MatchManager.opponentsOf(player);
        if (foes.isEmpty()) {   // outside a match everybody else counts
            foes = new ArrayList<>(player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(6.0),
                    e -> e != player && BallEntity.isActor(e)));
        }
        for (LivingEntity foe : foes) {
            best = Math.min(best, foe.distanceTo(player));
        }
        return best;
    }

    private static String bestOwned(PlayerProfile profile, String... orderedIds) {
        for (String id : orderedIds) {
            if (profile.isUnlocked(id)) {
                return id;
            }
        }
        return null;
    }

    /** Checks cooldown and stamina for a skill and pays for it. */
    private static boolean spendSkill(ServerPlayer player, PlayerState state, int action, String skillId, long now) {
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(skillId);
        if (def.isEmpty() || now < state.readyAt[action]) {
            return false;
        }
        if (!state.stamina.spend(def.get().staminaCost())) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return false;
        }
        state.startCooldown(action, now, def.get().cooldownTicks());
        return true;
    }

    /** Common start of an active skill: owned, off cooldown, enough stamina. Returns the player's state or null. */
    private static PlayerState begin(ServerPlayer player, int action, String skillId) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        if (profile.isEmpty()) {
            player.displayClientMessage(Component.translatable("bluelock.error.no_profile"), true);
            return null;
        }
        if (skillId == null || !profile.get().isUnlocked(skillId)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked", Component.translatable(
                    "bluelock.skill." + (skillId == null ? "awareness" : skillId) + ".name")), true);
            return null;
        }
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        return spendSkill(player, state, action, skillId, now) ? state : null;
    }

    private static void finishSkill(ServerPlayer player, String skillId) {
        AnimationBridge.playOnPlayer(player, AnimLogic.forSkill(skillId, 1));
        player.playNotifySound(ModSounds.SKILL.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, 1.0F);
        Rewards.give(player.getServer(), player.getUUID(), Progression.XpAction.SKILL_USED);
    }

    /** Vision key: shows free team-mates, open space and passing lanes for a few seconds (better with each vision skill). */
    private static void vision(ServerPlayer player) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        String id = profile.map(p -> bestOwned(p, "advanced_field_vision", "passing_lane_read", "spatial_read", "awareness")).orElse(null);
        PlayerState state = begin(player, ActionIds.VISION, id);
        if (state == null) {
            return;
        }
        state.visionSkill = id;
        state.visionUntil = player.level().getGameTime() + 80;
        finishSkill(player, id);
    }

    /** Defense key: Interception Read (catch passes near you) if owned, otherwise Shadow Marking (stick to the carrier). */
    private static void defense(ServerPlayer player) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        String id = profile.map(p -> bestOwned(p, "interception_read", "shadow_marking")).orElse(null);
        PlayerState state = begin(player, ActionIds.DEFENSE, id);
        if (state == null) {
            return;
        }
        long now = player.level().getGameTime();
        if (id.equals("interception_read")) {
            state.interceptUntil = now + 80;
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, false, false));
        } else {
            LivingEntity target = nearestOpponent(player);
            if (target != null) {
                state.markedId = target.getId();
                state.markUntil = now + 100;
            }
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1, false, false));
        }
        finishSkill(player, id);
    }

    private static LivingEntity nearestOpponent(ServerPlayer player) {
        List<LivingEntity> foes = MatchManager.opponentsOf(player);
        if (foes.isEmpty()) {
            foes = new ArrayList<>(player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(14.0),
                    e -> e != player && BallEntity.isActor(e)));
        }
        LivingEntity best = null;
        double bestDistance = 14.0;
        for (LivingEntity foe : foes) {
            double d = foe.distanceTo(player);
            if (BallEntity.carriesBall(foe)) {
                d -= 6.0;   // prefer the ball carrier
            }
            if (d < bestDistance) {
                bestDistance = d;
                best = foe;
            }
        }
        return best;
    }

    /** Focus key (Composure Focus): steadier passes and shots, no lost touches, and a little stamina back. */
    private static void focus(ServerPlayer player) {
        PlayerState state = begin(player, ActionIds.FOCUS, "composure_focus");
        if (state == null) {
            return;
        }
        long now = player.level().getGameTime();
        state.focusUntil = now + 120;
        state.noLossUntil = Math.max(state.noLossUntil, now + 120);
        state.stamina.restore(15);
        finishSkill(player, "composure_focus");
    }

    // ---------- slide tackle ----------

    private static void slide(ServerPlayer player) {
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        if (now < state.readyAt[ActionIds.SLIDE]) {
            return;
        }
        if (!state.stamina.spend(SLIDE_COST)) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return;
        }
        state.startCooldown(ActionIds.SLIDE, now, SLIDE_COOLDOWN);
        Vec3 heading = heading(player);
        state.slideX = heading.x;
        state.slideZ = heading.z;
        state.slideUntil = now + 10;
        AnimationBridge.playOnPlayer(player, "slide");
        player.playNotifySound(ModSounds.SKILL.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.8F, 0.8F);
    }

    // ---------- dribble skills and abilities ----------

    private static void skill(ServerPlayer player, int action) {
        String skillId = SKILL_FOR_ACTION[action];
        MinecraftServer server = player.getServer();
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(skillId);
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player.getUUID());
        if (def.isEmpty()) {
            return;
        }
        if (profile.isEmpty()) {
            player.displayClientMessage(Component.translatable("bluelock.error.no_profile"), true);
            return;
        }
        if (!profile.get().isUnlocked(skillId)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked",
                    Component.translatable(def.get().nameKey())), true);
            return;
        }
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        if (now < state.readyAt[action]) {
            return;
        }
        if (!state.stamina.spend(def.get().staminaCost())) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return;
        }
        state.startCooldown(action, now, def.get().cooldownTicks());

        Vec3 h = heading(player);
        Vec3 side = new Vec3(-h.z, 0, h.x);
        AnimationBridge.playOnPlayer(player, AnimLogic.forSkill(skillId, state.feintSide));
        switch (skillId) {
            case "feint" -> {
                push(player, side.scale(0.55 * state.feintSide * moveStrength(profile.get(), state.feintSide)).add(h.scale(0.15)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 12;
            }
            case "burst_dribble" -> {
                push(player, h.scale(0.8));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 1, false, false));
                state.immuneUntil = now + 14;
            }
            case "chain_dribble" -> {
                push(player, side.scale(0.4 * state.feintSide * moveStrength(profile.get(), state.feintSide)).add(h.scale(0.5)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 30;
                state.noLossUntil = now + 40;
            }
            case "sprint_burst" -> player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 50, 2, false, false));
            case "shoulder_charge" -> TackleActions.attempt(server, player, TackleActions.Mode.SHOULDER);
            default -> { }
        }
        player.playNotifySound(ModSounds.SKILL.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, 1.0F);
        boolean carrying = isCarryingBall(player);
        Rewards.give(server, player.getUUID(), carrying ? Progression.XpAction.DRIBBLE_MOVE : Progression.XpAction.SKILL_USED);
    }

    private static double moveStrength(PlayerProfile profile, int sideSign) {
        return FootModel.moveStrength(profile.foot(), sideSign);
    }

    private static boolean isCarryingBall(ServerPlayer player) {
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(4.0))) {
            if (ball.carrier() == player) {
                return true;
            }
        }
        return false;
    }

    private static void push(ServerPlayer player, Vec3 velocity) {
        player.setDeltaMovement(player.getDeltaMovement().add(velocity));
        player.hurtMarked = true;
    }

    /** Direction the player is running in, or the way they look when standing still. Unit vector, horizontal. */
    private static Vec3 heading(ServerPlayer player) {
        double dx = player.getX() - player.xo;
        double dz = player.getZ() - player.zo;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > 0.03) {
            return new Vec3(dx / len, 0, dz / len);
        }
        Vec3 look = player.getLookAngle();
        double l = Math.sqrt(look.x * look.x + look.z * look.z);
        return l < 1.0E-3 ? new Vec3(0, 0, 1) : new Vec3(look.x / l, 0, look.z / l);
    }
}
