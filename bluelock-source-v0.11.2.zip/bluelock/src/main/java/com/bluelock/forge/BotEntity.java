package com.bluelock.forge;

import com.bluelock.common.ai.BotDifficulty;
import com.bluelock.common.ai.BotStats;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.stats.StatBlock;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

/**
 * A football bot (the AI opponent or team-mate). It has no normal Minecraft AI: the match manager asks the bot
 * brain (common module) what to do a few times per second and tells the entity where to run.
 * Bots are not saved with the world and cannot be hurt.
 */
public class BotEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_SIDE = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_CARRYING = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.BOOLEAN);

    private Position botPosition = Position.CM;
    private int slotIndex;
    private int rating = 50;
    private StatBlock stats = BotStats.forRating(50, Position.CM);
    long tackleReadyAt;
    private int diveTicks;
    private double diveX;
    private double diveZ;
    private int diveSign;
    long keeperLockUntil;

    public BotEntity(EntityType<? extends BotEntity> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MOVEMENT_SPEED, 0.12D)
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_SIDE, 0);
        this.entityData.define(DATA_CARRYING, false);
    }

    public void configure(Side side, int slot, Position position, int rating, double speedFactor) {
        this.entityData.set(DATA_SIDE, side == Side.HOME ? 0 : 1);
        this.slotIndex = slot;
        this.botPosition = position;
        this.rating = rating;
        this.stats = BotStats.forRating(rating, position);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(BotDifficulty.movementAttribute(rating, speedFactor));
    }

    public Side side() {
        return this.entityData.get(DATA_SIDE) == 0 ? Side.HOME : Side.AWAY;
    }

    /** True while this bot has the ball at his feet (used by the animations). */
    public boolean isCarryingBall() {
        return this.entityData.get(DATA_CARRYING);
    }

    public void setCarrying(boolean carrying) {
        this.entityData.set(DATA_CARRYING, carrying);
    }

    /** Plays a one-shot animation (kick, tackle, dive...). Does nothing without the animation libraries. */
    public void animate(String name) {
        AnimationBridge.playOnBot(this, name);
    }

    public Position botPosition() { return botPosition; }
    public int slotIndex() { return slotIndex; }
    public int rating() { return rating; }
    public StatBlock stats() { return stats; }

    /** Runs toward a world spot. speedFactor 1.0 is the bot's top speed. */
    public void runTo(double x, double z, double speedFactor) {
        getMoveControl().setWantedPosition(x, getY(), z, speedFactor);
        getLookControl().setLookAt(x, getEyeY(), z);
    }

    public void stopRunning() {
        getNavigation().stop();
        getMoveControl().setWantedPosition(getX(), getY(), getZ(), 0.0D);
    }

    /** Bots own the passive skills their strength deserves. */
    public boolean hasSkill(String skillId) {
        return switch (skillId) {
            case "control" -> rating >= 45;
            case "finishing" -> rating >= 50;
            case "pressure_finisher" -> rating >= 70;
            default -> false;
        };
    }

    /** A slide tackle: a short dash toward the target. */
    public void startSlide(double dx, double dz) {
        double len = Math.max(1.0E-6, Math.sqrt(dx * dx + dz * dz));
        startDive(dx / len, dz / len, 1);
        this.diveTicks = 8;
    }

    /** The goalkeeper throws himself sideways. direction is the world-space sideways vector (unit), sign -1 or +1 (0 = no dive). */
    public void startDive(double dirX, double dirZ, int sign) {
        this.diveX = dirX * sign;
        this.diveZ = dirZ * sign;
        this.diveSign = sign;
        this.diveTicks = 10;
    }

    public boolean isDiving() {
        return diveTicks > 0;
    }

    public int diveSign() {
        return diveSign;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && diveTicks > 0) {
            setDeltaMovement(diveX * 0.55, getDeltaMovement().y, diveZ * 0.55);
            diveTicks--;
        }
    }

    @Override
    protected void registerGoals() {
        // no vanilla AI: the match manager drives bots
    }

    @Override
    public boolean removeWhenFarAway(double distanceSquared) {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
