package com.bluelock.forge;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/** Chooses the bot renderer: the GeckoLib one when the animation build is present, else the normal footballer model. Client only. */
public final class GeoClientSupport {
    private static final String GEO_RENDERER = "com.bluelock.forge.anim.GeoBotRenderer";

    private GeoClientSupport() {
    }

    @SuppressWarnings("unchecked")
    public static EntityRenderer<BotEntity> createBotRenderer(EntityRendererProvider.Context context) {
        if (AnimationBridge.botAnimationsAvailable()) {
            try {
                return (EntityRenderer<BotEntity>) Class.forName(GEO_RENDERER)
                        .getConstructor(EntityRendererProvider.Context.class).newInstance(context);
            } catch (ReflectiveOperationException | LinkageError e) {
                BlueLockMod.LOGGER.warn("GeckoLib bot renderer could not be created, using the plain one: {}", e.toString());
            }
        }
        return new BotRenderer(context);
    }
}
