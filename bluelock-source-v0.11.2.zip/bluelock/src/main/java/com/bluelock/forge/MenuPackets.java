package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Small helpers shared by the menu packets. */
final class MenuPackets {
    private MenuPackets() {
    }

    static void serverSide(Supplier<NetworkEvent.Context> contextSupplier, java.util.function.Consumer<ServerPlayer> work) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                work.accept(player);
            }
        });
        context.setPacketHandled(true);
    }

    static void write(FriendlyByteBuf buf, CompoundTag tag) {
        buf.writeNbt(tag);
    }
}
