package com.bluelock.forge;

/** Implemented by the GeckoLib bot (only present in the build with animation libraries). */
public interface AnimatedBot {
    void playAnimation(String name);
}
