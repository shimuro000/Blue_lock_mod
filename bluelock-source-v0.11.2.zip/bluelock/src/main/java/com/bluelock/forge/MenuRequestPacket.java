package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: please send me the current menu state. */
public record MenuRequestPacket() {
    public static void encode(MenuRequestPacket m, FriendlyByteBuf buf) {
    }

    public static MenuRequestPacket decode(FriendlyByteBuf buf) {
        return new MenuRequestPacket();
    }

    public static void handle(MenuRequestPacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, MenuServer::sendState);
    }
}
