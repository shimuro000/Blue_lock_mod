package com.bluelock.forge;

/** Numbers that identify a player action sent from the keyboard to the server. */
public final class ActionIds {
    public static final int PASS = com.bluelock.common.action.Actions.PASS;
    public static final int SHOT = 1;
    public static final int SLIDE = 2;
    public static final int FEINT = 3;
    public static final int BURST = 4;
    public static final int CHAIN = 5;
    public static final int SPRINT = 6;
    public static final int SHOULDER = 7;
    public static final int VISION = 8;
    public static final int DEFENSE = 9;
    public static final int FOCUS = 10;
    public static final int COUNT = com.bluelock.common.action.Actions.COUNT;

    private ActionIds() {
    }
}
