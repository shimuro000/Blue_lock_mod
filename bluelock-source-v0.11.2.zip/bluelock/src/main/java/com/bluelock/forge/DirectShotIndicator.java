package com.bluelock.forge;

import com.bluelock.common.action.DirectShot;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.Stat;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * The crosshair: when a player who owns Direct Shot is within 2 blocks of a loose ball (rolling or flying after a pass,
 * not at anybody's feet), a ring of particles appears around the ball, only for that player, and the action bar tells
 * which version of the direct shot the shot key will use. Better versions add more rings.
 */
final class DirectShotIndicator {
    private DirectShotIndicator() {
    }

    static void tick(ServerPlayer player) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        if (profile.isEmpty() || !profile.get().isUnlocked("direct_shot")) {
            return;
        }
        List<BallEntity> balls = player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(DirectShot.READY_RADIUS),
                b -> b.carrier() == null && b.distanceTo(player) <= DirectShot.READY_RADIUS);
        if (balls.isEmpty()) {
            return;
        }
        BallEntity ball = balls.get(0);
        DirectShot.Tier tier = DirectShot.bestTier(profile.get().unlockedSkills(),
                profile.get().stats().permanent(Stat.AWAKENING_POTENTIAL), profile.get().stats().permanent(Stat.EGO_AFFINITY));
        ServerLevel level = (ServerLevel) player.level();
        ring(level, player, ParticleTypes.END_ROD, ball, 0.55, 8);
        if (tier == DirectShot.Tier.PRECISION || tier == DirectShot.Tier.AWAKENING) {
            ring(level, player, ParticleTypes.ELECTRIC_SPARK, ball, 0.35, 6);
        }
        if (tier == DirectShot.Tier.AWAKENING) {
            ring(level, player, ParticleTypes.SOUL_FIRE_FLAME, ball, 0.75, 10);
        }
        player.displayClientMessage(Component.translatable("bluelock.skill.direct_ready",
                Component.translatable("bluelock.shot.tier." + tier.name().toLowerCase(java.util.Locale.ROOT))), true);
    }

    private static void ring(ServerLevel level, ServerPlayer player, ParticleOptions type, BallEntity ball, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            VisionEffects.puff(level, player, type, ball.getX() + Math.cos(angle) * radius, ball.getY() + 0.25, ball.getZ() + Math.sin(angle) * radius);
        }
    }
}
