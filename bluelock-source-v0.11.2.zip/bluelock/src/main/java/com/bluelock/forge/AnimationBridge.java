package com.bluelock.forge;

import java.lang.reflect.Constructor;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

/**
 * The only place that knows whether the animation libraries (GeckoLib, PlayerAnimator) are present.
 * The rest of the mod calls this class and works the same either way: without the libraries bots and
 * players simply keep the normal Minecraft look.
 */
public final class AnimationBridge {
    private static final String GEO_BOT_CLASS = "com.bluelock.forge.anim.GeoBotEntity";
    private static final String PLAYER_ANIM_CLASS = "com.bluelock.forge.anim.PlayerAnimClient";

    private static boolean geoChecked;
    private static Constructor<?> geoBotConstructor;
    private static volatile PlayerAnimBackend playerBackend;

    private AnimationBridge() {
    }

    /** Entity factory for bots: the animated GeckoLib bot when available, else the plain bot. */
    public static BotEntity createBot(EntityType<? extends BotEntity> type, Level level) {
        loadGeo();
        if (geoBotConstructor != null) {
            try {
                return (BotEntity) geoBotConstructor.newInstance(type, level);
            } catch (ReflectiveOperationException | LinkageError e) {
                BlueLockMod.LOGGER.warn("Animated bot could not be created, using the plain bot: {}", e.toString());
                geoBotConstructor = null;
            }
        }
        return new BotEntity(type, level);
    }

    private static synchronized void loadGeo() {
        if (geoChecked) {
            return;
        }
        geoChecked = true;
        try {
            geoBotConstructor = Class.forName(GEO_BOT_CLASS).getConstructor(EntityType.class, Level.class);
            BlueLockMod.LOGGER.info("GeckoLib bot animations are active");
        } catch (ReflectiveOperationException | LinkageError e) {
            BlueLockMod.LOGGER.info("GeckoLib bot animations are not available (basic bots)");
        }
    }

    public static boolean botAnimationsAvailable() {
        loadGeo();
        return geoBotConstructor != null;
    }

    public static boolean playerAnimationsAvailable() {
        return playerBackend != null;
    }

    public static PlayerAnimBackend playerBackend() {
        return playerBackend;
    }

    public static void setPlayerBackend(PlayerAnimBackend backend) {
        playerBackend = backend;
    }

    /** Client start-up: lets the PlayerAnimator part register itself if it exists. */
    public static void initClient() {
        try {
            Class.forName(PLAYER_ANIM_CLASS).getMethod("init").invoke(null);
            BlueLockMod.LOGGER.info("PlayerAnimator player animations are active");
        } catch (ReflectiveOperationException | LinkageError e) {
            BlueLockMod.LOGGER.info("PlayerAnimator is not available (normal player animations)");
        }
    }

    /** Server side: make everybody who can see this player play a one-shot animation. */
    public static void playOnPlayer(ServerPlayer player, String name) {
        if (name == null || name.isEmpty()) {
            return;
        }
        BlueLockNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), new PlayerAnimPacket(player.getId(), name));
    }

    public static void playOnBot(BotEntity bot, String name) {
        if (name != null && bot instanceof AnimatedBot animated) {
            animated.playAnimation(name);
        }
    }
}
