package com.bluelock.forge;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** The Blue Lock look (client only): deep navy, electric blue, cyan highlights, white text, gold for the talented. */
public final class BlueUi {
    public static final int NAVY = 0xFF07142E;
    public static final int NAVY_PANEL = 0xDD0B1E45;
    public static final int BLUE = 0xFF1E6BFF;
    public static final int CYAN = 0xFF3CC8FF;
    public static final int WHITE = 0xFFFFFFFF;
    public static final int GREY = 0xFF9FB3D1;
    public static final int RED = 0xFFE5383B;
    public static final int GOLD = 0xFFFFC83D;
    public static final int GREEN = 0xFF3DDC84;

    private static final String[] SLOGANS = {
            "bluelock.menu.slogan.1", "bluelock.menu.slogan.2", "bluelock.menu.slogan.3", "bluelock.menu.slogan.4"};

    private BlueUi() {
    }

    public static void background(GuiGraphics g, int width, int height) {
        g.fillGradient(0, 0, width, height, 0xFF040B1C, 0xFF0B2A66);
        // slanted electric-blue slashes
        int[] starts = {width / 6, width / 2, width - width / 5};
        for (int s : starts) {
            for (int y = 0; y < height; y += 2) {
                int x = s + (int) (y * 0.45);
                g.fill(x, y, x + 10, y + 2, 0x221E6BFF);
            }
        }
        g.fill(0, 0, 5, height, BLUE);
        g.fill(width - 5, 0, width, height, BLUE);
    }

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, NAVY_PANEL);
        g.fill(x, y, x + w, y + 1, CYAN);
        g.fill(x, y + h - 1, x + w, y + h, BLUE);
    }

    public static void bar(GuiGraphics g, int x, int y, int w, int h, int percent, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF15233F);
        g.fill(x, y, x + Math.max(0, Math.min(100, percent)) * w / 100, y + h, color);
    }

    public static void title(GuiGraphics g, Font font, int x, int y, float scale, Component text, int color) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1.0F);
        g.drawString(font, text, 0, 0, color, true);
        g.pose().popPose();
    }

    /** The slogan strip under the title; the line changes every five seconds. */
    public static void slogan(GuiGraphics g, Font font, int centreX, int y, int tick) {
        Component text = Component.translatable(SLOGANS[(tick / 100) % SLOGANS.length]);
        g.drawCenteredString(font, text, centreX, y, CYAN);
    }
}
