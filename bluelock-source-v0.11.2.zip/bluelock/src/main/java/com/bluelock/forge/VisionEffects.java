package com.bluelock.forge;

import com.bluelock.common.action.VisionLogic;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * What the vision skills show, drawn with particles that only the skill's owner sees:
 * Awareness marks the free team-mates in front of you, Spatial Read adds a column over the best open space,
 * Passing Lane Read draws the open lanes (and the blocked ones in smoke), Advanced Field Vision also marks every opponent.
 */
final class VisionEffects {
    private VisionEffects() {
    }

    static void tick(ServerPlayer player, PlayerState state, long now) {
        if (now >= state.visionUntil || now % 4 != 0 || state.visionSkill.isEmpty()) {
            return;
        }
        ServerLevel level = (ServerLevel) player.level();
        List<LivingEntity> mates = MatchManager.teammatesOf(player);
        List<LivingEntity> foes = MatchManager.opponentsOf(player);
        if (mates.isEmpty() && foes.isEmpty()) {   // outside a match: everybody nearby counts as a team-mate
            mates = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(40.0),
                    e -> e != player && BallEntity.isActor(e)));
        }
        List<double[]> matePositions = positions(mates);
        List<double[]> foePositions = positions(foes);
        double[] self = {player.getX(), player.getZ()};
        Vec3 look = player.getLookAngle();
        String skill = state.visionSkill;
        boolean lanes = skill.equals("passing_lane_read") || skill.equals("advanced_field_vision");
        boolean space = !skill.equals("awareness");
        boolean everyone = skill.equals("advanced_field_vision");

        List<Integer> open = VisionLogic.openMatesInView(self, look.x, look.z, matePositions, foePositions, 70, everyone ? 20 : 3);
        for (int index : open) {
            LivingEntity mate = mates.get(index);
            puff(level, player, ParticleTypes.HAPPY_VILLAGER, mate.getX(), mate.getY() + 2.4, mate.getZ());
        }
        if (everyone) {
            for (LivingEntity foe : foes) {
                puff(level, player, ParticleTypes.ANGRY_VILLAGER, foe.getX(), foe.getY() + 2.4, foe.getZ());
            }
        }
        if (space) {
            double[] spot = VisionLogic.bestSpace(self, look.x, look.z, foePositions, 12.0);
            if (spot != null) {
                for (int i = 0; i < 6; i++) {
                    puff(level, player, ParticleTypes.END_ROD, spot[0], player.getY() + 0.2 + i * 0.5, spot[1]);
                }
            }
        }
        if (lanes) {
            for (int i = 0; i < mates.size(); i++) {
                LivingEntity mate = mates.get(i);
                double distance = mate.distanceTo(player);
                if (distance < 3 || distance > 35) {
                    continue;
                }
                boolean blocked = VisionLogic.laneBlocked(self, matePositions.get(i), foePositions);
                ParticleOptions type = blocked ? ParticleTypes.SMOKE : ParticleTypes.END_ROD;
                for (double step = 1.5; step < distance; step += 1.5) {
                    double t = step / distance;
                    puff(level, player, type, player.getX() + (mate.getX() - player.getX()) * t,
                            player.getY() + 0.25, player.getZ() + (mate.getZ() - player.getZ()) * t);
                }
            }
        }
    }

    private static List<double[]> positions(List<LivingEntity> list) {
        List<double[]> out = new ArrayList<>();
        for (LivingEntity e : list) {
            out.add(new double[] {e.getX(), e.getZ()});
        }
        return out;
    }

    static void puff(ServerLevel level, ServerPlayer viewer, ParticleOptions type, double x, double y, double z) {
        level.sendParticles(viewer, type, true, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }
}
