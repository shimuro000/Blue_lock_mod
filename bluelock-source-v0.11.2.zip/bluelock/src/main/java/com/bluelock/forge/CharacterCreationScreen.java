package com.bluelock.forge;

import com.bluelock.common.content.Position;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.CharacterRoll;
import com.bluelock.common.profile.Personality;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/**
 * "Enter Blue Lock": name, favourite position, football background and personality are chosen here;
 * the dominant foot (60% right, 30% left, 10% both) and the talent (25% Genius) are rolled by the server (client only).
 */
public class CharacterCreationScreen extends Screen {
    private static final Position[] POSITIONS = Position.values();
    private static final Archetype[] ARCHETYPES = Archetype.values();
    private static final Personality[] PERSONALITIES = Personality.values();

    private EditBox nameBox;
    private int positionIndex = java.util.Arrays.asList(POSITIONS).indexOf(Position.ST);
    private int archetypeIndex;
    private int personalityIndex;
    private String error = "";
    private int scroll;
    private int contentBottom;
    private final java.util.List<AbstractWidget> scrolling = new java.util.ArrayList<>();
    private final java.util.List<Integer> originalY = new java.util.ArrayList<>();
    private int ticks;
    private int lastVersion = -1;

    public CharacterCreationScreen() {
        super(Component.translatable("bluelock.create.title"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        ticks++;
        if (ticks == 1 || ticks % 40 == 0) {
            BlueLockNetwork.CHANNEL.sendToServer(new MenuRequestPacket());
        }
        if (lastVersion != ClientMenuState.version) {
            lastVersion = ClientMenuState.version;
            if (ClientMenuState.hasProfile) {
                onClose();   // the character exists now
            }
        }
    }

    private <T extends AbstractWidget> T scrolled(T widget) {
        scrolling.add(widget);
        originalY.add(widget.getY());
        return addRenderableWidget(widget);
    }

    private int viewTop() {
        return 62;
    }

    private int viewBottom() {
        return height - 30;
    }

    private int maxScroll() {
        return Math.max(0, contentBottom - viewBottom() + 6);
    }

    private void applyScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        for (int i = 0; i < scrolling.size(); i++) {
            AbstractWidget w = scrolling.get(i);
            int y = originalY.get(i) - scroll;
            w.setY(y);
            w.visible = y >= viewTop() && y + w.getHeight() <= viewBottom();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll() > 0) {
            scroll -= (int) (delta * 24);
            applyScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    protected void init() {
        scrolling.clear();
        originalY.clear();
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 210);
        int y = 70;
        String previous = nameBox == null ? "" : nameBox.getValue();
        nameBox = new EditBox(font, rightX, y, w, 20, Component.translatable("bluelock.create.name"));
        nameBox.setMaxLength(16);
        nameBox.setValue(previous);
        nameBox.setHint(Component.translatable("bluelock.create.name_hint"));
        scrolled(nameBox);
        setInitialFocus(nameBox);
        y += 26;
        scrolled(new BlueButton(rightX, y, w, 20, Component.translatable("bluelock.create.position", POSITIONS[positionIndex].name()),
                b -> {
                    positionIndex = (positionIndex + 1) % POSITIONS.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20,
                Component.translatable("bluelock.create.archetype", Component.translatable("bluelock.archetype." + ARCHETYPES[archetypeIndex].name().toLowerCase(Locale.ROOT))),
                b -> {
                    archetypeIndex = (archetypeIndex + 1) % ARCHETYPES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20,
                Component.translatable("bluelock.create.personality", Component.translatable("bluelock.personality." + PERSONALITIES[personalityIndex].name().toLowerCase(Locale.ROOT))),
                b -> {
                    personalityIndex = (personalityIndex + 1) % PERSONALITIES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 80;
        scrolled(new BlueButton(rightX, y, w, 24, Component.translatable("bluelock.create.confirm"), b -> confirm(), BlueUi.GREEN));
        contentBottom = y + 24;
        applyScroll();
        addRenderableWidget(new BlueButton(width - 70, height - 24, 60, 16, Component.translatable("bluelock.menu.close"), b -> onClose(), BlueUi.RED));
    }

    private void confirm() {
        String name = nameBox.getValue().trim();
        if (name.length() < 2) {
            error = Component.translatable("bluelock.error.name_too_short").getString();
            return;
        }
        BlueLockNetwork.CHANNEL.sendToServer(new CreatePacket(name,
                ARCHETYPES[archetypeIndex].name().toLowerCase(Locale.ROOT),
                PERSONALITIES[personalityIndex].name().toLowerCase(Locale.ROOT),
                POSITIONS[positionIndex].name().toLowerCase(Locale.ROOT)));
        error = "";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, width / 2 - 100, 12, 2.5F, Component.translatable("bluelock.create.title"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2, 40, ticks);

        int previewX = width / 4;
        BlueUi.panel(g, 20, 56, width / 2 - 30, height - 90);
        if (minecraft != null && minecraft.player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, previewX, height - 70, 60, previewX - mouseX, height - 160 - mouseY, minecraft.player);
        }

        // the destiny panel: foot and talent rolled by the server
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 210);
        int y = 70 + 26 + 24 * 3 - 4 - scroll;
        boolean genius = "GENIUS".equals(ClientMenuState.rollTalent);
        boolean visibleBox = y >= viewTop() && y + 72 <= viewBottom();
        if (visibleBox) {
            renderDestiny(g, rightX, y, w, genius);
        }
        if (!error.isEmpty()) {
            g.drawString(font, error, rightX, height - 24, BlueUi.RED, true);
        }
        if (maxScroll() > 0) {
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(14, trackH * trackH / (trackH + maxScroll()));
            int thumbY = viewTop() + (trackH - thumbH) * scroll / maxScroll();
            g.fill(width - 8, viewTop(), width - 5, viewBottom(), 0x55000000);
            g.fill(width - 8, thumbY, width - 5, thumbY + thumbH, BlueUi.CYAN);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void renderDestiny(GuiGraphics g, int rightX, int y, int w, boolean genius) {
        BlueUi.panel(g, rightX, y, w, 72);
        g.drawString(font, Component.translatable("bluelock.create.destiny"), rightX + 6, y + 6, BlueUi.CYAN, true);
        Component foot = Component.translatable("bluelock.create.foot", Component.translatable("bluelock.foot." + ClientMenuState.rollFoot.toLowerCase(Locale.ROOT)));
        g.drawString(font, foot, rightX + 6, y + 20, BlueUi.WHITE, true);
        Component talent = Component.translatable(genius ? "bluelock.create.talent_genius" : "bluelock.create.talent_normal");
        g.drawString(font, talent, rightX + 6, y + 33, genius ? BlueUi.GOLD : BlueUi.WHITE, true);
        g.drawString(font, Component.translatable(genius ? "bluelock.create.genius_effects" : "bluelock.create.normal_effects"), rightX + 6, y + 46, BlueUi.GREY, true);
        g.drawString(font, Component.translatable("bluelock.create.odds",
                (int) (CharacterRoll.RIGHT_CHANCE * 100), (int) (CharacterRoll.LEFT_CHANCE * 100),
                (int) (100 - CharacterRoll.RIGHT_CHANCE * 100 - CharacterRoll.LEFT_CHANCE * 100), (int) (CharacterRoll.GENIUS_CHANCE * 100)),
                rightX + 6, y + 59, BlueUi.GREY, false);
    }
}
