package com.bluelock.common.content;

import java.util.Map;

/** A quest (data/bluelock/definitions/quests/<id>.json): do something {@code target} times for a reward. */
public record QuestDefinition(String id, QuestType type, int target, int rewardXp, int rewardSkillPoints, int rewardDevelopmentPoints) {

    public String nameKey() {
        return "bluelock.quest." + id + ".name";
    }

    public String descriptionKey() {
        return "bluelock.quest." + id + ".desc";
    }

    static QuestDefinition parse(String id, Map<String, Object> m) {
        return new QuestDefinition(id, Fields.enumValue(m, "type", QuestType.class),
                Fields.integer(m, "target", 1, 10_000),
                Fields.integerOr(m, "reward_xp", 0, 0, 100_000),
                Fields.integerOr(m, "reward_skill_points", 0, 0, 100),
                Fields.integerOr(m, "reward_development_points", 0, 0, 1000));
    }
}
