package com.bluelock.common.action;

import java.util.Map;

/**
 * How each skill is used in game. Every skill in the data files must appear here (a test checks it), so no skill
 * is "decoration". PASSIVE skills work by themselves; KEY skills have their own key; SNEAK_PASS is the pass key
 * while sneaking; SHOT_VARIANT skills upgrade the shot key when the ball is loose and within reach.
 */
public final class SkillBindings {
    public enum Kind { PASSIVE, KEY, SNEAK_PASS, SHOT_VARIANT }

    public record Binding(Kind kind, int action) {
    }

    private static final Binding PASSIVE = new Binding(Kind.PASSIVE, -1);
    private static final Binding SHOT_VARIANT = new Binding(Kind.SHOT_VARIANT, Actions.SHOT);
    private static final Binding VISION = new Binding(Kind.KEY, Actions.VISION);
    private static final Binding DEFENSE = new Binding(Kind.KEY, Actions.DEFENSE);

    private static final Map<String, Binding> BINDINGS = Map.ofEntries(
            Map.entry("finishing", PASSIVE),
            Map.entry("direct_shot", SHOT_VARIANT),
            Map.entry("precision_direct_shot", SHOT_VARIANT),
            Map.entry("pressure_finisher", PASSIVE),
            Map.entry("awakening_direct_shot", SHOT_VARIANT),
            Map.entry("control", PASSIVE),
            Map.entry("feint", new Binding(Kind.KEY, Actions.FEINT)),
            Map.entry("burst_dribble", new Binding(Kind.KEY, Actions.BURST)),
            Map.entry("chain_dribble", new Binding(Kind.KEY, Actions.CHAIN)),
            Map.entry("awareness", VISION),
            Map.entry("spatial_read", VISION),
            Map.entry("passing_lane_read", VISION),
            Map.entry("advanced_field_vision", VISION),
            Map.entry("through_pass", new Binding(Kind.SNEAK_PASS, Actions.PASS)),
            Map.entry("sprint_burst", new Binding(Kind.KEY, Actions.SPRINT)),
            Map.entry("shadow_marking", DEFENSE),
            Map.entry("interception_read", DEFENSE),
            Map.entry("shoulder_charge", new Binding(Kind.KEY, Actions.SHOULDER)),
            Map.entry("composure_focus", new Binding(Kind.KEY, Actions.FOCUS)));

    private SkillBindings() {
    }

    /** Null for an unknown skill id. */
    public static Binding of(String skillId) {
        return BINDINGS.get(skillId);
    }

    public static java.util.Set<String> knownSkills() {
        return BINDINGS.keySet();
    }
}
