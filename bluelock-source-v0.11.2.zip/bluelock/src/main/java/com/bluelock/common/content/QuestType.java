package com.bluelock.common.content;

/** What a quest counts. */
public enum QuestType { GOALS, TACKLES, PASSES, SHOTS, SKILL_MOVES, MATCHES, WINS }
