package com.bluelock.common.action;

import java.util.Set;

/**
 * The direct (first-time) shot: hitting a loose ball, rolling or flying after a pass, without a setup touch.
 * Three versions, picked automatically from the skills you own and your stats: Direct, Precision, Awakening.
 */
public final class DirectShot {
    /** How close (blocks) the ball must be for the crosshair to appear and the shot to work. */
    public static final double READY_RADIUS = 2.0;
    public static final double PRESSURE_DISTANCE = 3.0;
    public static final int AWAKENING_MIN_POTENTIAL = 55;
    public static final int AWAKENING_MIN_EGO = 55;

    public enum Tier { NONE, DIRECT, PRECISION, AWAKENING }

    /** spread and power multiply the normal shot; aimBlend is how strongly the shot is pulled toward the goal. */
    public record Tuning(double spreadMul, double powerMul, double aimBlend, int extraStamina) {
    }

    private DirectShot() {
    }

    public static Tier bestTier(Set<String> unlocked, int awakeningPotential, int egoAffinity) {
        if (unlocked.contains("awakening_direct_shot") && awakeningPotential >= AWAKENING_MIN_POTENTIAL && egoAffinity >= AWAKENING_MIN_EGO) {
            return Tier.AWAKENING;
        }
        if (unlocked.contains("precision_direct_shot")) return Tier.PRECISION;
        if (unlocked.contains("direct_shot")) return Tier.DIRECT;
        return Tier.NONE;
    }

    /** A normal shot with the ball at your feet (no direct-shot version involved). */
    public static Tuning normalShot(boolean pressured, boolean finishing, boolean pressureSkill, boolean focused) {
        double spread = 1.0;
        double power = 1.0;
        if (finishing) spread *= 0.9;
        if (focused) spread *= 0.6;
        if (pressured) {
            if (pressureSkill) {
                spread *= 0.9;
                power *= 1.05;
            } else {
                spread *= 1.35;
            }
        }
        return new Tuning(spread, power, 0.7, 0);
    }

    /**
     * @param pressured    an opponent is close
     * @param finishing    owns the Finishing skill (passive accuracy)
     * @param pressureSkill owns Pressure Finisher (no accuracy loss under pressure)
     * @param focused      Composure Focus is active
     */
    public static Tuning tuning(Tier tier, boolean pressured, boolean finishing, boolean pressureSkill, boolean focused) {
        double spread;
        double power;
        double aim;
        int stamina = 0;
        switch (tier) {
            case DIRECT -> { spread = 1.0; power = 1.10; aim = 0.35; }
            case PRECISION -> { spread = 0.4; power = 1.05; aim = 0.9; }
            case AWAKENING -> { spread = 0.2; power = 1.35; aim = 0.9; stamina = 20; }
            default -> { spread = 1.5; power = 0.95; aim = 0.0; }   // a loose-ball shot without the skill is hard to hit well
        }
        if (finishing) spread *= 0.9;
        if (focused) spread *= 0.6;
        if (pressured) {
            if (pressureSkill) {
                spread *= 0.9;
                power *= 1.05;
            } else {
                spread *= 1.35;
            }
        }
        return new Tuning(spread, power, aim, stamina);
    }
}
