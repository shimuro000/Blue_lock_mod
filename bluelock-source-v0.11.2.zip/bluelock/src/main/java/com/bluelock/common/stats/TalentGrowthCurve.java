package com.bluelock.common.stats;

import com.bluelock.common.profile.Talent;

/** The default growth bands, scaled by the player's talent: a Genius pays less per level and can climb higher. */
public final class TalentGrowthCurve implements GrowthCurve {
    private final Talent talent;
    private final GrowthCurve base = new DefaultGrowthCurve();

    private TalentGrowthCurve(Talent talent) {
        this.talent = talent;
    }

    public static TalentGrowthCurve of(Talent talent) {
        return new TalentGrowthCurve(talent);
    }

    @Override
    public int softCap() {
        return talent.softCap();
    }

    @Override
    public int costToRaise(int currentValue) {
        return Math.max(1, (int) Math.ceil(base.costToRaise(currentValue) * talent.growthCostMultiplier()));
    }
}
