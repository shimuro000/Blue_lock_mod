package com.bluelock.common.content;

public enum Position { GK, CB, LB, RB, LWB, RWB, CDM, CM, CAM, LM, RM, LW, RW, CF, ST }
