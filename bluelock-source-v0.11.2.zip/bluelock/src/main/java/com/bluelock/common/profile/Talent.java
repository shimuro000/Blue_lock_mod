package com.bluelock.common.profile;

/**
 * Natural talent, rolled once when a character is created. A Genius starts stronger, learns faster, gains XP faster
 * and can grow all the way to 99, while a Normal player tops out at 92 without a milestone.
 */
public enum Talent {
    NORMAL(0, 1.00, 92, 1.00),
    GENIUS(2, 0.75, 99, 1.15);

    private final int startingBonus;
    private final double growthCostMultiplier;
    private final int softCap;
    private final double xpMultiplier;

    Talent(int startingBonus, double growthCostMultiplier, int softCap, double xpMultiplier) {
        this.startingBonus = startingBonus;
        this.growthCostMultiplier = growthCostMultiplier;
        this.softCap = softCap;
        this.xpMultiplier = xpMultiplier;
    }

    /** Added to every starting stat. */
    public int startingBonus() { return startingBonus; }
    public double growthCostMultiplier() { return growthCostMultiplier; }
    /** Highest value reachable by normal training. */
    public int softCap() { return softCap; }
    public double xpMultiplier() { return xpMultiplier; }

    public String langKey() {
        return "bluelock.talent." + name().toLowerCase(java.util.Locale.ROOT);
    }
}
