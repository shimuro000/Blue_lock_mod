package com.bluelock.common.action;

/** Numbers that identify a player action (keyboard key). The Forge side mirrors these in ActionIds. */
public final class Actions {
    public static final int PASS = 0;
    public static final int SHOT = 1;
    public static final int SLIDE = 2;
    public static final int FEINT = 3;
    public static final int BURST = 4;
    public static final int CHAIN = 5;
    public static final int SPRINT = 6;
    public static final int SHOULDER = 7;
    public static final int VISION = 8;
    public static final int DEFENSE = 9;
    public static final int FOCUS = 10;
    public static final int COUNT = 11;

    private Actions() {
    }
}
