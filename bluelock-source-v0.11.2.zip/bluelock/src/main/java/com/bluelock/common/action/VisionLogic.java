package com.bluelock.common.action;

import java.util.ArrayList;
import java.util.List;

/** The maths behind the vision skills: which team-mates are free, which passing lanes are open, where the open space is. */
public final class VisionLogic {
    public static final double MARKED_DISTANCE = 3.0;
    public static final double LANE_WIDTH = 2.0;

    private VisionLogic() {
    }

    /** A team-mate is "open" when no opponent stands within MARKED_DISTANCE of him. Positions are {x, z}. */
    public static boolean isOpen(double[] mate, List<double[]> foes) {
        for (double[] f : foes) {
            if (Math.hypot(f[0] - mate[0], f[1] - mate[1]) < MARKED_DISTANCE) return false;
        }
        return true;
    }

    /** True if an opponent stands in the way of a pass from -> to. */
    public static boolean laneBlocked(double[] from, double[] to, List<double[]> foes) {
        double dx = to[0] - from[0], dz = to[1] - from[1];
        double len2 = dx * dx + dz * dz;
        for (double[] f : foes) {
            double t = len2 == 0 ? 0 : ((f[0] - from[0]) * dx + (f[1] - from[1]) * dz) / len2;
            if (t <= 0 || t >= 1) continue;
            double px = from[0] + t * dx, pz = from[1] + t * dz;
            if (Math.hypot(f[0] - px, f[1] - pz) < LANE_WIDTH) return true;
        }
        return false;
    }

    /** Indices of the open team-mates in front of the player (within the view cone), nearest first, at most maxCount. */
    public static List<Integer> openMatesInView(double[] self, double lookX, double lookZ, List<double[]> mates,
                                                List<double[]> foes, double coneDegrees, int maxCount) {
        List<Integer> result = new ArrayList<>();
        double ll = Math.hypot(lookX, lookZ);
        if (ll < 1.0E-9) return result;
        List<double[]> scored = new ArrayList<>();
        for (int i = 0; i < mates.size(); i++) {
            double dx = mates.get(i)[0] - self[0], dz = mates.get(i)[1] - self[1];
            double d = Math.hypot(dx, dz);
            if (d < 2 || d > 40) continue;
            double cos = (dx * lookX + dz * lookZ) / (d * ll);
            if (Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, cos)))) > coneDegrees) continue;
            if (!isOpen(mates.get(i), foes)) continue;
            scored.add(new double[] {i, d});
        }
        scored.sort((a, b) -> Double.compare(a[1], b[1]));
        for (double[] s : scored) {
            if (result.size() >= maxCount) break;
            result.add((int) s[0]);
        }
        return result;
    }

    /**
     * The best open space ahead: samples spots on a ring in front and picks the one farthest from every opponent.
     * Returns {x, z}, or null if nothing is at least 4 blocks from all opponents.
     */
    public static double[] bestSpace(double[] self, double lookX, double lookZ, List<double[]> foes, double radius) {
        double ll = Math.hypot(lookX, lookZ);
        if (ll < 1.0E-9) return null;
        double ux = lookX / ll, uz = lookZ / ll;
        double[] best = null;
        double bestClear = 4.0;
        for (int deg = -60; deg <= 60; deg += 15) {
            double a = Math.toRadians(deg);
            double dx = ux * Math.cos(a) - uz * Math.sin(a);
            double dz = ux * Math.sin(a) + uz * Math.cos(a);
            double[] spot = {self[0] + dx * radius, self[1] + dz * radius};
            double clear = Double.MAX_VALUE;
            for (double[] f : foes) clear = Math.min(clear, Math.hypot(f[0] - spot[0], f[1] - spot[1]));
            if (clear > bestClear) {
                bestClear = clear;
                best = spot;
            }
        }
        return best;
    }
}
