package com.bluelock.forge.anim;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.match.Side;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** Tells GeckoLib which model, animations and kit texture a bot uses. */
public class GeoBotModel extends GeoModel<GeoBotEntity> {
    private static final ResourceLocation MODEL = new ResourceLocation(BlueLockConstants.MOD_ID, "geo/entity/bot.geo.json");
    private static final ResourceLocation ANIMATIONS = new ResourceLocation(BlueLockConstants.MOD_ID, "animations/entity/bot.animation.json");
    private static final ResourceLocation HOME = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/entity/bot_home.png");
    private static final ResourceLocation AWAY = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/entity/bot_away.png");

    @Override
    public ResourceLocation getModelResource(GeoBotEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(GeoBotEntity animatable) {
        return animatable.side() == Side.HOME ? HOME : AWAY;
    }

    @Override
    public ResourceLocation getAnimationResource(GeoBotEntity animatable) {
        return ANIMATIONS;
    }
}
