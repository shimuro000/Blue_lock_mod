package com.bluelock.forge.anim;

import com.bluelock.common.anim.AnimLogic;
import com.bluelock.forge.AnimatedBot;
import com.bluelock.forge.BotEntity;
import java.util.List;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * The animated footballer bot (GeckoLib). One controller picks the movement animation (idle, walk, run, sprint,
 * jump, and the same with the ball); a second one plays one-shot actions (kicks, tackles, skills, dives, catches).
 * This class is only compiled when the animation libraries are part of the build.
 */
public class GeoBotEntity extends BotEntity implements GeoEntity, AnimatedBot {
    /** One-shot animations the server can trigger. */
    private static final List<String> ACTIONS = List.of(
            "kick_pass", "kick_shot", "tackle_stand", "slide", "feint_left", "feint_right", "burst", "chain_spin",
            "sprint_burst", "shoulder", "dive_left", "dive_right", "catch", "celebrate",
            "volley", "awakening_shot", "through_pass", "scan", "stance", "focus");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public GeoBotEntity(EntityType<? extends BotEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "locomotion", 4, this::locomotion));
        AnimationController<GeoBotEntity> action = new AnimationController<>(this, "action", 1, state -> PlayState.STOP);
        for (String name : ACTIONS) {
            action.triggerableAnim(name, RawAnimation.begin().thenPlay(name));
        }
        controllers.add(action);
    }

    private PlayState locomotion(AnimationState<GeoBotEntity> state) {
        double speed = Math.hypot(getX() - xo, getZ() - zo);
        boolean airborne = Math.abs(getY() - yo) > 0.08;
        String name = AnimLogic.locomotion(speed, isCarryingBall(), airborne, true);
        return state.setAndContinue(RawAnimation.begin().thenLoop(name));
    }

    @Override
    public void playAnimation(String name) {
        if (ACTIONS.contains(name)) {
            triggerAnim("action", name);
        }
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
