package com.bluelock.common;

import com.bluelock.common.action.*;
import com.bluelock.common.content.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class SkillsSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws IOException {
        // every skill in the data files has a way to be used
        List<String> ids = new ArrayList<>();
        try (Stream<Path> files = Files.list(Path.of("src/main/resources/data/bluelock/definitions/skills"))) {
            for (Path f : files.filter(p -> p.toString().endsWith(".json")).toList()) ids.add(f.getFileName().toString().replace(".json", ""));
        }
        check(ids.size() == 19, "19 skills in the data (" + ids.size() + ")");
        List<String> unbound = new ArrayList<>();
        for (String id : ids) if (SkillBindings.of(id) == null) unbound.add(id);
        check(unbound.isEmpty(), "every skill has a binding" + (unbound.isEmpty() ? "" : " - missing: " + unbound));
        check(SkillBindings.knownSkills().containsAll(ids) && SkillBindings.knownSkills().size() == ids.size(), "no binding for a skill that does not exist");
        boolean keysInRange = true;
        for (String id : ids) {
            var b = SkillBindings.of(id);
            if (b.kind() == SkillBindings.Kind.KEY || b.kind() == SkillBindings.Kind.SNEAK_PASS || b.kind() == SkillBindings.Kind.SHOT_VARIANT) keysInRange &= b.action() >= 0 && b.action() < Actions.COUNT;
        }
        check(keysInRange && Actions.COUNT == 11, "all bound actions are valid action numbers");
        long passives = ids.stream().filter(i -> SkillBindings.of(i).kind() == SkillBindings.Kind.PASSIVE).count();
        check(passives == 3, "3 passive skills (finishing, pressure finisher, control): " + passives);

        // direct shot versions
        Set<String> none = Set.of(), direct = Set.of("direct_shot"), prec = Set.of("direct_shot", "precision_direct_shot");
        Set<String> awake = Set.of("direct_shot", "precision_direct_shot", "awakening_direct_shot");
        check(DirectShot.bestTier(none, 90, 90) == DirectShot.Tier.NONE && DirectShot.bestTier(direct, 90, 90) == DirectShot.Tier.DIRECT && DirectShot.bestTier(prec, 0, 0) == DirectShot.Tier.PRECISION, "the best owned version is picked");
        check(DirectShot.bestTier(awake, 70, 70) == DirectShot.Tier.AWAKENING, "awakening version needs the skill and the stats");
        check(DirectShot.bestTier(awake, 30, 80) == DirectShot.Tier.PRECISION && DirectShot.bestTier(awake, 80, 30) == DirectShot.Tier.PRECISION, "without Awakening Potential and Ego the awakening shot falls back to precision");
        var t0 = DirectShot.tuning(DirectShot.Tier.NONE, false, false, false, false);
        var t1 = DirectShot.tuning(DirectShot.Tier.DIRECT, false, false, false, false);
        var t2 = DirectShot.tuning(DirectShot.Tier.PRECISION, false, false, false, false);
        var t3 = DirectShot.tuning(DirectShot.Tier.AWAKENING, false, false, false, false);
        check(t0.spreadMul() > t1.spreadMul() && t1.spreadMul() > t2.spreadMul() && t2.spreadMul() > t3.spreadMul(), "each version is more accurate than the one before");
        check(t3.powerMul() > t2.powerMul() && t2.powerMul() < t1.powerMul() + 0.1 && t1.powerMul() > t0.powerMul() && t3.extraStamina() > 0, "awakening shot is the most powerful and costs extra stamina");
        check(t2.aimBlend() > t1.aimBlend() && t1.aimBlend() > t0.aimBlend(), "better versions aim more toward the goal");
        var pressed = DirectShot.tuning(DirectShot.Tier.PRECISION, true, false, false, false);
        var pressedSkill = DirectShot.tuning(DirectShot.Tier.PRECISION, true, false, true, false);
        check(pressed.spreadMul() > t2.spreadMul() && pressedSkill.spreadMul() < t2.spreadMul() && pressedSkill.powerMul() > t2.powerMul(), "pressure hurts accuracy, Pressure Finisher turns it into a bonus");
        check(DirectShot.tuning(DirectShot.Tier.DIRECT, false, true, false, false).spreadMul() < t1.spreadMul() && DirectShot.tuning(DirectShot.Tier.DIRECT, false, false, false, true).spreadMul() < t1.spreadMul(), "Finishing and Composure Focus improve accuracy");
        check(DirectShot.READY_RADIUS == 2.0, "the crosshair appears within 2 blocks of the ball");

        // vision
        List<double[]> foes = List.of(new double[] {10, 0});
        check(!VisionLogic.isOpen(new double[] {11, 1}, foes) && VisionLogic.isOpen(new double[] {20, 5}, foes), "a team-mate next to an opponent is marked, a free one is open");
        check(VisionLogic.laneBlocked(new double[] {0, 0}, new double[] {20, 0}, foes) && !VisionLogic.laneBlocked(new double[] {0, 0}, new double[] {20, 10}, foes), "an opponent on the line blocks the lane");
        List<double[]> mates = List.of(new double[] {8, 0}, new double[] {10, 1}, new double[] {-8, 0}, new double[] {15, 4}, new double[] {25, 2});
        List<Integer> open = VisionLogic.openMatesInView(new double[] {0, 0}, 1, 0, mates, foes, 60, 3);
        check(open.equals(List.of(3, 4)), "vision marks only the free team-mates in front, nearest first (" + open + ")");
        check(VisionLogic.openMatesInView(new double[] {0, 0}, 1, 0, mates, foes, 60, 1).size() == 1, "at most the requested number of marks");
        double[] space = VisionLogic.bestSpace(new double[] {0, 0}, 1, 0, List.of(new double[] {10, 0}), 12);
        check(space != null && Math.hypot(space[0] - 10, space[1]) > 4, "best open space is away from opponents");
        check(VisionLogic.bestSpace(new double[] {0, 0}, 1, 0, List.of(new double[] {8, 0}, new double[] {8, 8}, new double[] {8, -8}, new double[] {11, 11}, new double[] {11, -11}, new double[] {12, 0}), 12) == null || true, "no crash when the space is crowded");

        System.out.println(failures == 0 ? "ALL SKILLS TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
