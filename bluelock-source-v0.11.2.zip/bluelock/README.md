# Blue Lock (Minecraft Java 1.20.1, Forge 47.4.0)

Football RPG mod inspired by Blue Lock. See `BUILDING.md` to build and run it.

Status: 0.11.2 makes all 19 skills work, adds direct-shot crosshair, vision, defense and focus skills, and full animations for players and bots. See docs/TESTING.md.

## Layout
- `src/main/java/com/bluelock/common`  loader-independent game logic (no Forge imports allowed here)
- `src/main/java/com/bluelock/forge`   Forge entry point, events, commands, registration
- `src/main/resources/assets/bluelock` language files (en_us, ar_sa), later textures/models/sounds
- `src/test/java`                       unit tests for common logic (later)
- `docs/`                               design docs (ARCHITECTURE.md, ...)
